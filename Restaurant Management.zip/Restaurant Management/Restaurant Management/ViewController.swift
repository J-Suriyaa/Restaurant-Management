//
//  ViewController.swift
//  Restaurant Management
//
//  Created by Jeyasuriyaa Jeyakumar on 22/07/20.
//  Copyright © 2020 Jeyasuriyaa Jeyakumar. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }


}

